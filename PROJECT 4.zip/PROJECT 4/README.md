# Classic Arcade Game Clone Project

## Table of Contents

- [Instructions](#instructions)
- [Contributing](#contributing)

## Instructions

- use the index page to initiate the game
- you have only 3 lives available
- make sure to avoid all the bugs to win
- when you hit the bug , the game will restart automatically
- ENJOY :) !! 

## Contributing

This repository is the starter code for _all_ Udacity students. Therefore, we most likely will not accept pull requests.
