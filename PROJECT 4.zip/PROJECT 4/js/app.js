//variables of Y axis movement for the bug
var movementValueY=[30,50,80,120,210];
var count=0;
// Enemies our player must avoid
var Enemy = function() {
    // Variables applied to each of our instances go here,
    // we've provided one for you to get started

    // The image/sprite for our enemies, this uses
    // a helper we've provided to easily load images
    this.sprite = 'images/enemy-bug.png';
    this.x=0;//intial value for the x
    this.y=movementValueY[Math.floor(Math.random() * 2)];//random selection of the movement of the y axis for the bugs
    this.speed = Math.floor(100 + (Math.random() * 100)); // the speed of the bugs in the Y axis
};

// Update the enemy's position, required method for game
// Parameter: dt, a time delta between ticks
Enemy.prototype.update = function(dt) {
    // You should multiply any movement by the dt parameter
    // which will ensure the game runs at the same speed for
    // all computers.
    this.x += this.speed * dt;
    if (this.x > 505) { //to check and change the bug speed once it goes out of the frame
        this.x = -101;
        this.y = this.y + 83;
        this.speed = Math.floor(100 + (Math.random() * 100));

        if (this.y > 226) { // to determine the Y locatin on the grass rows
            this.y = 60;
          }
      }
        checkCollision(this, player);//incrementing the counter of the collision between the enemy and the hero

};

// Draw the enemy on the screen, required method for game
Enemy.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};

// Now write your own player class
// This class requires an update(), render() and
// a handleInput() method.
var Player = function() { //setting up the needed intital values for the Player variable
    this.sprite = 'images/char-cat-girl.png';
    this.x = 200;
    this.y = 400;
    return this;
};
Player.prototype.update = function() { //using the keys in the keyboard to move the Player
    if (this.KEY === 'left' && this.x !== 0) {
        this.x = this.x - 100;
    } else if (this.KEY === 'right' && this.x != 400) {
        this.x = this.x + 100;
    } else if (this.KEY === 'up') {
        this.y = this.y - 83;
    } else if (this.KEY === 'down' && this.y != 400) {
        this.y = this.y + 83;
    }
    this.KEY = null;//I use the null value to avoid the movement in one direction

    if (this.y < 60) { // reset the Player location to begin the game again
        alert('YOU ARE A WINNER!');
        player.reset();
    }
  };
  Player.prototype.render = function() {
      ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
  };

  Player.prototype.handleInput = function(key){
      this.KEY = key;
  };
  Player.prototype.reset = function() {//function used to reset the player location to the borders of the canvas
      this.x = 200;
      this.y = 400;
  };
  var counter = 0;
  var checkCollision = function(bug, hero) { // to check hits between the enemy and the hero

      if (!(bug.y + 83 < hero.y || bug.y > hero.y + 83 || bug.x + 100 < hero.x || bug.x > hero.x + 100)) {
              counter = counter + 1;
              if(counter >= 3) { // limited hits between the hero and the enemy
                  alert('YOU LOST!\n' + '\n'+'PLAY AGAIN');
                  counter = 0;
              }
              // else {
              //   do nothing
              // }
              hero.reset();
          }
  };
  var enemies = 6;//Number of Enemies
  var allEnemies = []; //Array of allEnemies

  for (var i = 0; i < enemies; i++) {
      allEnemies.push(new Enemy());
  }

  var player = new Player();

// This listens for key presses and sends the keys to your
// Player.handleInput() method. You don't need to modify this.
document.addEventListener('keyup', function(e) {
    var allowedKeys = {
        37: 'left',
        38: 'up',
        39: 'right',
        40: 'down'
    };

    player.handleInput(allowedKeys[e.keyCode]);
});
